document.addEventListener("DOMContentLoaded", () => {
    console.log("BOT ON Website Loaded");
});